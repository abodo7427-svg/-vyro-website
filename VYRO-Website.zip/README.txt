VYRO — Cinematic Visuals
========================
نسخة أولية جاهزة للعرض محليًا.

الملفات:
- index.html
- style.css
- script.js

للنشر: ارفع الملفات إلى أي استضافة Static مثل Netlify / Vercel / GitHub Pages.
استبدل الخلفيات التجريبية بصور VYRO الحقيقية، وأضف روابط Instagram وWhatsApp.
